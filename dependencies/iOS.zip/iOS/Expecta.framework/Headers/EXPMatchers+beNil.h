#import "Expecta.h"

EXPMatcherInterface(beNil, (void));
EXPMatcherInterface(beNull, (void));
