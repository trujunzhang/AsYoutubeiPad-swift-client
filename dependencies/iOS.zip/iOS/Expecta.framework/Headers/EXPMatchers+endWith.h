#import "Expecta.h"

EXPMatcherInterface(endWith, (id expected));
