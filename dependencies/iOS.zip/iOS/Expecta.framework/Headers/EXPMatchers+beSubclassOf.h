#import "Expecta.h"

EXPMatcherInterface(beSubclassOf,  (Class expected));
EXPMatcherInterface(beASubclassOf, (Class expected));
