#import "Expecta.h"

EXPMatcherInterface(beginWith, (id expected));
EXPMatcherInterface(startWith, (id expected));
