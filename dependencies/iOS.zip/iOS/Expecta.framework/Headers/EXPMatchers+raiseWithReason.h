#import "Expecta.h"

EXPMatcherInterface(raiseWithReason, (NSString *expectedExceptionName, NSString *expectedReason));
